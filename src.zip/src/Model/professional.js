const mongoose = require('mongoose');

const locationSchema = new mongoose.Schema({
  address: String,
  zip_code: String,
  city: String,
  contact: String,
  latitude: { type: Number, index: true }, 
  longitude: { type: Number, index: true }, 
});

const professionalSchema = new mongoose.Schema({
  name: String,
  sex: String,
  state: String,
  mainCategory: {
    type: String,
  },
  locations: [locationSchema],
  education_and_training: String,
  board_certifications: [String],
  specialities: [String],
  group_affiliations: [String],
  affiliations: {
    Hospital: [String],
  },
  reviews: [
    {
      name: { type: String },
      email: { type: String },
      reviews: { type: String },
      starRating: { type: Number },
      date: { type: Date, default: Date.now },
    },
  ],
  complain: [
    {
      name: { type: String },
      email: { type: String },
      complain: { type: String },
      date: { type: Date, default: Date.now },
    },
  ],
  provides_telehealth_services: Boolean,
});

const Professional = mongoose.model('Professional', professionalSchema);

module.exports = Professional;
