const mongoose = require('mongoose');

const locationSchema = new mongoose.Schema({
    address: String,
    zip_code: String,
    city: String,
    contact: String,
    latitude: Number,
    longitude: Number
});

const doctorSchema = new mongoose.Schema({
    name: String,
    sex: String,
    state: String,
    locations: [locationSchema],
    education_and_training: String,
    board_certifications: [String],
    specialities: [String],
    group_affiliations: [String],
    affiliations: {
        Hospital: [String]
    },
    provides_telehealth_services: Boolean
});

const Doctor = mongoose.model('Professionals', doctorSchema);

module.exports = Doctor;
